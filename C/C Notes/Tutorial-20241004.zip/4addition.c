//Program to add two numbers
#include<stdio.h>
int main()
{
    int num1 = 5,num2 = 10, sum;
    sum = num1 + num2;
    printf("The addition of two numbers %d and %d is:%d\n",num1,num2,sum);
    return 0;
}