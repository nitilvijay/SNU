//Count Hello World Program
#include<stdio.h>
int main()
{
    printf("\n%d\n",printf("\nNumber of letters in Hello World is: %d\n",printf("\nHello World\n")));
    return 0;
}